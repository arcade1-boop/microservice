package com.cognizant.ecommerce.services;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.ecommerce.dtos.AuditRequestDTO;
import com.cognizant.ecommerce.dtos.AuditResponseDTO;
import com.cognizant.ecommerce.entities.Audit;
import com.cognizant.ecommerce.exceptions.AuditLogNotFoundException;
import com.cognizant.ecommerce.mappers.AuditMapper;
import com.cognizant.ecommerce.repositories.AuditRepository;

import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@AllArgsConstructor
public class AuditServiceImpl implements AuditService {
	
	@Autowired
	public AuditRepository repository;
	@Autowired 
	public AuditMapper auditMapper;
	
	@Override
	public AuditResponseDTO createAudit(AuditRequestDTO request) {
		Audit audit = repository.save(auditMapper.toAuditEntity(request));
		System.out.println("Response : " + audit);
		return auditMapper.toAuditResponse(audit);
	}

	@Override
	public AuditResponseDTO getAudit(Long id) {
		Audit audit = repository.findById(id).orElse(null);
		return auditMapper.toAuditResponse(audit);
	}

	@Override
	public List<AuditResponseDTO> getAllAudits() {
		List<Audit> audit = repository.findAll();
		return auditMapper.toAuditResponse(audit);
	}

	@Override
	public AuditResponseDTO updateAudit(Long id, AuditRequestDTO request) {
		
		Audit audit = repository.findById(id).orElse(null);
		if(audit!=null) {
			audit = repository.save(auditMapper.toAuditEntity(request));
		}
		return auditMapper.toAuditResponse(audit);
	}

	@Override
	public void deleteAudit(Long id) {
		
		if(!repository.existsById(id)) {
			throw new AuditLogNotFoundException(id);
		}
		
		repository.deleteById(id);
		
	}

	

	



}