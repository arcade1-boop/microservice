package com.cognizant.ecommerce.dtos;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import lombok.Data;

@Data
public class AuditRequestDTO {

	private String service_name;

	private String operation;

	private String record_id;

	private String details;
}
