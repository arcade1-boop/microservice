package com.cognizant.ecommerce.mappers;

import java.time.LocalDateTime;

import com.cognizant.ecommerce.dtos.AuditRequestDTO;
import com.cognizant.ecommerce.dtos.AuditResponseDTO;
import com.cognizant.ecommerce.entities.Audit;

public class ItemMapper {

    // Converts incoming Request (from other services) to the Database Entity
    public static Audit toEntity(AuditRequestDTO dto) {
        return Audit.builder()
                .service_name(dto.getService_name())
                .operation(dto.getOperation())
                .record_id(dto.getRecord_id())
                .details(dto.getDetails())
                .timestamp(LocalDateTime.now()) // Captures when log was created
                .build();
    }

    // Converts the Database Entity to a Response DTO for the Client/API
    public static AuditResponseDTO toDTO(Audit entity) {
        return AuditResponseDTO.builder()
                .id(entity.getId())
                .service_name(entity.getService_name())
                .operation(entity.getOperation())
                .record_id(entity.getRecord_id())
                .details(entity.getDetails())
                .timestamp(entity.getTimestamp())
                .build();
    }
}