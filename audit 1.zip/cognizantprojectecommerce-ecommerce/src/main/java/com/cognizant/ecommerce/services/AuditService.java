package com.cognizant.ecommerce.services;
import java.util.List;

import com.cognizant.ecommerce.dtos.AuditRequestDTO;
import com.cognizant.ecommerce.dtos.AuditResponseDTO;

public interface AuditService {

    AuditResponseDTO createAudit(AuditRequestDTO request);

    AuditResponseDTO getAudit(Long id);

    List<AuditResponseDTO> getAllAudits();

    AuditResponseDTO updateAudit(Long id, AuditRequestDTO request);

    void deleteAudit(Long id);

}