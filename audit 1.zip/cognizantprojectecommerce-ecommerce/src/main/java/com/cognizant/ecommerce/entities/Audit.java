package com.cognizant.ecommerce.entities;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Table(name = "audit")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Audit {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(nullable = false)
	private String service_name;

	private String operation;

	private String record_id;

	@CreationTimestamp
	@Column(nullable=false, updatable=false)
	private LocalDateTime timestamp;
	private String details;

	
}