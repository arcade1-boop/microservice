package com.cognizant.ecommerce.controllers;

public class InventoryController {

}
