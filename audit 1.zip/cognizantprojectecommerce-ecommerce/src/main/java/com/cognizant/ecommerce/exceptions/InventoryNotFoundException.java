package com.cognizant.ecommerce.exceptions;

public class InventoryNotFoundException {

}
