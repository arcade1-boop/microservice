package com.cognizant.ecommerce.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.ecommerce.entities.Audit;

public interface AuditRepository extends JpaRepository<Audit, Long> {
	
}