package com.cognizant.ecommerce.repositories;

public class NotificationRepository {

}
