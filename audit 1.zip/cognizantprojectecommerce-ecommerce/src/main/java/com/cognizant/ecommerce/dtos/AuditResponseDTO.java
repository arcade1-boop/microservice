package com.cognizant.ecommerce.dtos;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;

import jakarta.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AuditResponseDTO {
	private Long id;

	private String service_name;

	private String operation;

	private String record_id;

	private LocalDateTime timestamp;
	
	private String details;
}