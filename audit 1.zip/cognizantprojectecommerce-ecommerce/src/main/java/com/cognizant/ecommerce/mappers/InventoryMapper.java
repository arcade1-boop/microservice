package com.cognizant.ecommerce.mappers;

public class InventoryMapper {

}
