//package com.cognizant.ecommerce.controllers;
// 
//import java.util.List;
// 
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
// 
//import com.cognizant.ecommerce.dtos.ItemRequestDTO;
//import com.cognizant.ecommerce.dtos.ItemResponseDTO;
//import com.cognizant.ecommerce.entities.Item;
//import com.cognizant.ecommerce.mappers.ItemMapper;
//import com.cognizant.ecommerce.services.ItemService;
// 
// 
//import lombok.RequiredArgsConstructor;
// 
//@RestController
//@RequestMapping("/api/items")
//@RequiredArgsConstructor
//public class ItemController {
// 
//    private final ItemService service;
// 
//    @PostMapping(value="/",consumes = "application/json")
//    public ItemResponseDTO create(@RequestBody ItemRequestDTO request) {
//    	System.out.println("req "+request);
//    	Item item = ItemMapper.toEntity(request);
//        return ItemMapper.toDTO(service.createItem(item));
//    }
// 
//    @GetMapping("/{id}")
//    public ItemResponseDTO get(@PathVariable Long id) {
//        return service.getItem(id);
//    }
// 
//    @GetMapping
//    public List<ItemResponseDTO> getAll() {
//        return service.getAllItems();
//    }
// 
//    @PutMapping("/{id}")
//    public ItemResponseDTO update(@PathVariable Long id,
//                                  @RequestBody ItemRequestDTO request) {
//        return service.updateItem(id, request);
//    }
// 
//    @DeleteMapping("/{id}")
//    public void delete(@PathVariable Long id) {
//        service.deleteItem(id);
//    }
//}
// 