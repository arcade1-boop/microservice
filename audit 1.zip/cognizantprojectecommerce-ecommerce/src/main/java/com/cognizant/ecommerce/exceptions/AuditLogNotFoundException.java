package com.cognizant.ecommerce.exceptions;

import java.io.Serializable;

public class AuditLogNotFoundException extends RuntimeException implements Serializable{

    public AuditLogNotFoundException(Long id) {
        super("Item not found with id: " + id);
    }
}