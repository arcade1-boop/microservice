package com.cognizant.ecommerce.mappers;

import java.util.List;

import org.mapstruct.Mapper;

import com.cognizant.ecommerce.dtos.AuditRequestDTO;
import com.cognizant.ecommerce.dtos.AuditResponseDTO;
import com.cognizant.ecommerce.entities.Audit;

@Mapper(componentModel="spring")
public interface AuditMapper {

    Audit toAuditEntity(AuditRequestDTO auditDto);
    AuditResponseDTO toAuditResponse(Audit audit);
    
    List<Audit> toAuditEntity(List<AuditRequestDTO> auditDto);
    List<AuditResponseDTO> toAuditResponse(List<Audit> audit);
    
}