package com.cognizant.ecommerce.entities;

public class Inventory {

}
