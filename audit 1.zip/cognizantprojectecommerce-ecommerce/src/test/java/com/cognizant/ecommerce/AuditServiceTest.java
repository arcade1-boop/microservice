package com.cognizant.ecommerce;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cognizant.ecommerce.dtos.AuditResponseDTO;
import com.cognizant.ecommerce.entities.Audit;
import com.cognizant.ecommerce.repositories.AuditRepository;
import com.cognizant.ecommerce.services.AuditServiceImpl;

@ExtendWith(MockitoExtension.class) // Correct way to test Services
class AuditServiceTest {

    @Mock
    private AuditRepository repository;

    @InjectMocks
    private AuditServiceImpl service;

    @Test
    void testGetAuditLog() {
        // 1. Create a proper Audit entity (Matching your schema: serviceName, operation)
        Audit audit = new Audit();
        audit.setId(1L);
        audit.setService_name("Item Service");
        audit.setOperation("CREATE");

        // 2. Setup the mock behavior
        when(repository.findById(1L)).thenReturn(Optional.of(audit));

        // 3. Execute the service method (Ensure method name matches your implementation)
        AuditResponseDTO result = service.getAudit(1L);

        // 4. Assert using Audit fields, not Item fields
        assertEquals("Item Service", result.getService_name());
        assertEquals("CREATE", result.getOperation());
    }
}