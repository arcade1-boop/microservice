package com.cognizant.ecommerce.repositories;

public class AuditRepository {

}
