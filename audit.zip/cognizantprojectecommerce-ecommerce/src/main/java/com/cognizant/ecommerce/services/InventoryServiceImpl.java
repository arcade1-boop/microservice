package com.cognizant.ecommerce.services;

public class InventoryServiceImpl {

}
