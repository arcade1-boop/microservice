package com.cognizant.ecommerce.dtos;

public class NotificationRequestDTO {

}
