package com.cognizant.inventory;
 
 
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
 
import com.cognizant.inventory.dtos.InventoryRequestDTO;
import com.cognizant.inventory.dtos.InventoryResponseDTO;
import com.cognizant.inventory.entities.Inventory;
import com.cognizant.inventory.exceptions.InventoryNotFoundException;
import com.cognizant.inventory.repositories.InventoryRepository;
import com.cognizant.inventory.services.InventoryServiceImpl;
 
import java.time.LocalDateTime;
import java.util.Optional;
 
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
 
@ExtendWith(MockitoExtension.class)
public class InventoryServiceTest {
 
    @Mock
    private InventoryRepository inventoryRepository;
 
    @InjectMocks
    private InventoryServiceImpl inventoryService;
 
    private Inventory inventory;
    private InventoryRequestDTO requestDTO;
 
    @BeforeEach
    void setUp() {
        // Sample entity for mocking
        inventory = Inventory.builder()
                .id(1L)
                .itemId("ITEM-123")
                .quantity(100L)
                .warehouseLocation("Kolkata")
                .lastUpdated(LocalDateTime.now())
                .build();
 
        // Sample request DTO
        requestDTO = new InventoryRequestDTO("ITEM-123", 100L, "Kolkata");
    }
 
    @Test
    void createInventory_Success() {
        // Arrange
        when(inventoryRepository.save(any(Inventory.class))).thenReturn(inventory);
 
        // Act
        InventoryResponseDTO response = inventoryService.createInventory(requestDTO);
 
        // Assert
        assertNotNull(response);
        assertEquals("ITEM-123", response.getItemId());
        verify(inventoryRepository, times(1)).save(any(Inventory.class));
    }
 
    @Test
    void getInventoryById_Success() {
        // Arrange
        when(inventoryRepository.findById(1L)).thenReturn(Optional.of(inventory));
 
        // Act
        InventoryResponseDTO response = inventoryService.getInventoryById(1L);
 
        // Assert
        assertNotNull(response);
        assertEquals(1L, response.getId());
        assertEquals("Kolkata", response.getWarehouseLocation());
    }
 
    @Test
    void getInventoryById_NotFound_ThrowsException() {
        // Arrange
        when(inventoryRepository.findById(2L)).thenReturn(Optional.empty());
 
        // Act & Assert
        assertThrows(InventoryNotFoundException.class, () -> {
            inventoryService.getInventoryById(2L);
        });
    }
 
    @Test
    void updateInventory_Success() {
        // Arrange
        when(inventoryRepository.findById(1L)).thenReturn(Optional.of(inventory));
        when(inventoryRepository.save(any(Inventory.class))).thenReturn(inventory);
 
        // Act
        InventoryResponseDTO response = inventoryService.updateInventory(1L, requestDTO);
 
        // Assert
        assertNotNull(response);
        verify(inventoryRepository).save(any(Inventory.class));
    }
 
    @Test
    void deleteInventory_Success() {
        // Arrange
        when(inventoryRepository.existsById(1L)).thenReturn(true);
 
        // Act
        inventoryService.deleteInventory(1L);
 
        // Assert
        verify(inventoryRepository, times(1)).deleteById(1L);
    }
 
    @Test
    void deleteInventory_NotFound_ThrowsException() {
        // Arrange
        when(inventoryRepository.existsById(5L)).thenReturn(false);
 
        // Act & Assert
        assertThrows(InventoryNotFoundException.class, () -> {
            inventoryService.deleteInventory(5L);
        });
        
        // Ensure delete was never called
        verify(inventoryRepository, never()).deleteById(5L);
    }
}